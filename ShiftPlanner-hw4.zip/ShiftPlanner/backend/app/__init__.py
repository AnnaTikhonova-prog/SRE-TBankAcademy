"""Пакет приложения ShiftPlanner."""
