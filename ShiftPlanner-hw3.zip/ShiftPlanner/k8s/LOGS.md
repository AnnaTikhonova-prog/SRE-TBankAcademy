# Развёртывание Victoria Logs и Vector

Манифесты `07-victoria-logs.yaml` и `08-vector.yaml` добавляют Victoria Logs
single-node с PVC и Vector DaemonSet. Vector читает логи подов на узле,
оставляет только контейнер `backend` из namespace `shiftplanner`, разбирает
JSON и отправляет записи через `/insert/jsonline`. В кластере сервис доступен
как `victoria-logs.victoria-logs.svc.cluster.local:9428`.

## Запуск

Из корня репозитория, если minikube остановлен:

```powershell
minikube start
docker build -t shiftplanner-backend:1.1 .\ShiftPlanner\backend
minikube image load shiftplanner-backend:1.1
kubectl apply -f .\ShiftPlanner\k8s\05-backend.yaml
kubectl rollout status deployment/backend -n shiftplanner
kubectl apply -f .\ShiftPlanner\k8s\07-victoria-logs.yaml
kubectl rollout status deployment/victoria-logs -n victoria-logs
kubectl apply -f .\ShiftPlanner\k8s\08-vector.yaml
kubectl rollout status daemonset/vector -n shiftplanner
```

Проверка приёма логов:

```powershell
kubectl logs -n shiftplanner deployment/backend --tail=10
kubectl logs -n shiftplanner daemonset/vector --tail=50
kubectl port-forward -n victoria-logs service/victoria-logs 9428:9428
```

Откройте `http://localhost:9428/select/vmui/`. В текущей версии Victoria Logs
проверен именно этот путь (старый `/vmui/` отвечает ошибкой). Когда понадобится внешний доступ к
приложению, его Service остаётся в namespace `shiftplanner`.

## Запросы LogsQL

Все запросы ограничивают выборку последними 15 минутами:

1. Сырые записи: `_time:15m | sort by (_time desc) | limit 100`
2. Уровень журнала: `_time:15m level:info`
3. Число записей по уровню: `_time:15m | stats by (level) count() logs | format "<level> logs=<logs>" as _msg | fields level, logs, _msg`
4. Самые частые HTTP-пути: `_time:15m http.path:* | top 5 by (http.path) | format "<http.path> hits=<hits>" as _msg | fields http.path, hits, _msg`

Логи Uvicorn access содержат поля `http.path` и `http.status_code`; записи
приложения содержат `timestamp`, `level`, `message`, `service.name` и `logger`.
