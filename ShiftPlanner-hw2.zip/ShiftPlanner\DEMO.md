minikube status       
cd C:\Users\asus\PycharmProjects\SRE-TBankAcademy\ShiftPlanner
ls .\k8s\                                   

kubectl apply -f .\k8s\                      
kubectl get pods -n shiftplanner -w          
kubectl get all -n shiftplanner              
kubectl get pvc -n shiftplanner             

kubectl scale deployment backend -n shiftplanner --replicas=3  
kubectl get pods -n shiftplanner -w          

minikube service frontend -n shiftplanner    

kubectl get pods -n shiftplanner